const questions = [
  {
    question: "Küresel ısınmanın en büyük nedeni nedir?",
    options: ["Ağaç dikmek", "Fosil yakıt kullanımı", "Geri dönüşüm", "Rüzgar enerjisi"],
    answer: "Fosil yakıt kullanımı"
  },
  {
    question: "İklim değişikliği neden olur?",
    options: ["Doğal afetler", "Atmosferdeki sera gazları", "Su döngüsü", "Toprak erozyonu"],
    answer: "Atmosferdeki sera gazları"
  },
  {
    question: "Karbondioksit salınımını azaltmak için ne yapmalıyız?",
    options: ["Fosil yakıtları kullanmaya devam etmek", "Toplu taşıma kullanmak", "Ormanları kesmek", "Elektrik tüketimini artırmak"],
    answer: "Toplu taşıma kullanmak"
  }
];

let currentQuestion = 0;

function loadQuestion() {
  const q = questions[currentQuestion];
  document.getElementById("question").innerText = q.question;
  const optionsHtml = q.options.map(option => 
    `<button onclick="checkAnswer('${option}')">${option}</button>`
  ).join("");
  document.getElementById("options").innerHTML = optionsHtml;
}

function checkAnswer(selected) {
  const isCorrect = selected === questions[currentQuestion].answer;
  if (isCorrect) {
    currentQuestion++;
    if (currentQuestion < questions.length) {
      loadQuestion();
    } else {
      document.getElementById("quiz").innerHTML = "<p>Test tamamlandı! Tebrikler 🎉</p>";
    }
  } else {
    alert("Yanlış cevap. Tekrar deneyin.");
  }
}

document.addEventListener("DOMContentLoaded", loadQuestion);
